import os
import joblib
import pandas as pd
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.conf import settings
from django.contrib.auth.decorators import login_required

def load_saved_objects():
    model_path = os.path.join(settings.BASE_DIR, "Model", "diet_pipeline.joblib")
    encoders_path = os.path.join(settings.BASE_DIR, "Model", "label_encoders.joblib")
    loaded = {}
    if os.path.exists(model_path):
        loaded['pipeline'] = joblib.load(model_path)
    else:
        loaded['pipeline'] = None
    if os.path.exists(encoders_path):
        loaded['encoders'] = joblib.load(encoders_path)
    else:
        loaded['encoders'] = {}
    return loaded

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email', '')
        name = request.POST.get('name', '')
        if User.objects.filter(username=username).exists():
            return render(request, 'register.html', {'msg': 'Username already exists'})
        User.objects.create_user(username=username, email=email, password=password, first_name=name)
        return render(request, 'register.html', {'msg': 'Registration successful'})
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('predict_view')
        return render(request, 'login.html', {'msg': 'Login Failed'})
    return render(request, 'login.html')

@login_required
def predict_view(request):
    context = {}
    if request.method == 'POST':
        input_data = {
            'Age': request.POST.get('Age', ''),
            'Gender': request.POST.get('Gender', ''),
            'Weight_kg': request.POST.get('Weight_kg', ''),
            'Height_cm': request.POST.get('Height_cm', ''),
        }
        df = pd.DataFrame([input_data])
        for col in ['Age', 'Weight_kg', 'Height_cm']:
            if col in df.columns:
                try:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(-1)
                except Exception:
                    df[col] = -1
        saved = load_saved_objects()
        pipeline = saved.get('pipeline', None)
        encoders = saved.get('encoders', {})
        if pipeline is None:
            context['error'] = "Model pipeline not found. Please contact the admin."
            return render(request, 'predict.html', context)
        try:
            pred = pipeline.predict(df)
            if hasattr(pred, '__len__'):
                pred_val = pred[0]
            else:
                pred_val = pred
            if 'target' in encoders:
                try:
                    label = encoders['target'].inverse_transform([int(pred_val)])[0]
                except Exception:
                    label = str(pred_val)
            else:
                label = str(pred_val)
            context['prediction'] = label
        except Exception as e:
            context['error'] = f"Prediction failed: {str(e)}"
    return render(request, 'predict.html', context)
