from django.urls import path, include

urlpatterns = [
    path('', include('diet_app.urls')),
]
